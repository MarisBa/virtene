# Christmas lights

Light display using HTML, CSS & JavaScript

![christmas lights simulation with html, css & javascript](https://media.giphy.com/media/kbQcrL4KRpaUAon7kg/giphy.gif)
